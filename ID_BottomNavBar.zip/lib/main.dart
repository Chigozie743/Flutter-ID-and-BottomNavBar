// ignore_for_file: prefer_const_constructo
import 'package:flutter/material.dart';

import 'idapp2.dart';

// void main() => runApp(Home());

void main() => runApp(new MaterialApp(
      home: SkillupCard(),
    ));
